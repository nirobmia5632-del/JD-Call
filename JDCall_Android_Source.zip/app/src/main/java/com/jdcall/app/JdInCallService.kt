package com.jdcall.app

import android.telecom.Call
import android.telecom.InCallService
import android.util.Log

/**
 * Minimal Telecom binding scaffold.
 *
 * A production phone app must implement call callbacks, show incoming/ongoing call UI,
 * manage answer/reject/disconnect actions, audio routes, notifications, and lifecycle.
 * This class intentionally does not claim to be a complete dialer.
 */
class JdInCallService : InCallService() {
    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.i("JDCall", "Telecom delivered a call. Add full incoming/ongoing call UI here.")
        // TODO: Register Call.Callback and launch a compliant call UI/notification.
        // TODO: Implement answer/reject/disconnect and audio route controls.
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.i("JDCall", "Telecom call removed.")
    }
}
