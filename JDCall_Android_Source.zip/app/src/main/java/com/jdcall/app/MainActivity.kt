package com.jdcall.app

import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.BasicTextField
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Call
import androidx.compose.material.icons.filled.Contacts
import androidx.compose.material.icons.filled.History
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.VoiceChat
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.net.toUri

private val Navy = Color(0xFF173B59)
private val Blue = Color(0xFF2476C8)
private val Pale = Color(0xFFF3F7FB)
private val Green = Color(0xFF18A66A)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { JDCallApp(this) }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
private fun JDCallApp(context: Context) {
    var number by remember { mutableStateOf("") }
    var selectedTab by remember { mutableStateOf(0) }
    var message by remember { mutableStateOf("SIM কলের জন্য নম্বর লিখুন") }

    MaterialTheme(
        colorScheme = lightColorScheme(
            primary = Navy,
            secondary = Blue,
            background = Pale,
            surface = Color.White
        )
    ) {
        Scaffold(
            topBar = {
                TopAppBar(
                    title = {
                        Column {
                            Text("JD Call", fontWeight = FontWeight.Bold, fontSize = 23.sp)
                            Text("Stay connected", fontSize = 12.sp, color = Color.White.copy(alpha = .8f))
                        }
                    },
                    colors = TopAppBarDefaults.topAppBarColors(
                        containerColor = Navy,
                        titleContentColor = Color.White
                    ),
                    actions = {
                        IconButton(onClick = {
                            requestDialerRole(context)
                            message = "ডিফল্ট Phone app করার অনুরোধ দেখানো হবে (Android সমর্থন করলে)"
                        }) {
                            Icon(Icons.Default.Settings, contentDescription = "Set default phone app", tint = Color.White)
                        }
                    }
                )
            },
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    NavigationBarItem(
                        selected = selectedTab == 0,
                        onClick = { selectedTab = 0 },
                        icon = { Icon(Icons.Default.Call, contentDescription = null) },
                        label = { Text("Keypad") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 1,
                        onClick = { selectedTab = 1 },
                        icon = { Icon(Icons.Default.History, contentDescription = null) },
                        label = { Text("History") }
                    )
                    NavigationBarItem(
                        selected = selectedTab == 2,
                        onClick = { selectedTab = 2 },
                        icon = { Icon(Icons.Default.Contacts, contentDescription = null) },
                        label = { Text("Contacts") }
                    )
                }
            },
            containerColor = Pale
        ) { padding ->
            when (selectedTab) {
                0 -> Column(
                    modifier = Modifier.fillMaxSize().padding(padding).padding(20.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Spacer(Modifier.height(22.dp))
                    Box(
                        modifier = Modifier.size(88.dp).background(Navy, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(Icons.Default.Call, contentDescription = null, tint = Color.White, modifier = Modifier.size(42.dp))
                    }
                    Spacer(Modifier.height(12.dp))
                    Text("Make a call", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Navy)
                    Text("SIM call or internet call", color = Color.Gray, fontSize = 14.sp)
                    Spacer(Modifier.height(28.dp))

                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        shadowElevation = 2.dp
                    ) {
                        Column(Modifier.padding(18.dp)) {
                            Text("Phone number", fontWeight = FontWeight.SemiBold, color = Navy)
                            Spacer(Modifier.height(12.dp))
                            BasicTextField(
                                value = number,
                                onValueChange = { number = it.filter { ch -> ch.isDigit() || ch == '+' || ch == '*' || ch == '#' } },
                                modifier = Modifier.fillMaxWidth().background(Pale, RoundedCornerShape(12.dp)).padding(16.dp),
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                textStyle = androidx.compose.ui.text.TextStyle(fontSize = 24.sp, color = Navy),
                                decorationBox = { inner ->
                                    if (number.isEmpty()) Text("01XXXXXXXXX", color = Color.LightGray, fontSize = 22.sp)
                                    inner()
                                }
                            )
                            Spacer(Modifier.height(18.dp))
                            Button(
                                onClick = {
                                    if (number.isBlank()) message = "আগে একটি ফোন নম্বর লিখুন"
                                    else {
                                        val intent = Intent(Intent.ACTION_DIAL, Uri.fromParts("tel", number, null))
                                        context.startActivity(intent)
                                        message = "সিস্টেম Phone app খুলেছে; কল করতে সেখানে নিশ্চিত করুন"
                                    }
                                },
                                modifier = Modifier.fillMaxWidth().height(52.dp),
                                colors = ButtonDefaults.buttonColors(containerColor = Green),
                                shape = RoundedCornerShape(14.dp)
                            ) {
                                Icon(Icons.Default.Call, contentDescription = null)
                                Spacer(Modifier.width(8.dp))
                                Text("SIM Call", fontSize = 17.sp, fontWeight = FontWeight.Bold)
                            }
                        }
                    }

                    Spacer(Modifier.height(18.dp))
                    Surface(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(18.dp),
                        color = Color.White,
                        shadowElevation = 1.dp
                    ) {
                        Row(Modifier.padding(16.dp), verticalAlignment = Alignment.CenterVertically) {
                            Box(Modifier.size(46.dp).background(Color(0xFFE4F2FF), CircleShape), contentAlignment = Alignment.Center) {
                                Icon(Icons.Default.VoiceChat, contentDescription = null, tint = Blue)
                            }
                            Spacer(Modifier.width(12.dp))
                            Column(Modifier.weight(1f)) {
                                Text("Internet Call", fontWeight = FontWeight.Bold, color = Navy)
                                Text("App-to-app voice calling", fontSize = 13.sp, color = Color.Gray)
                            }
                            OutlinedButton(onClick = {
                                message = "ইন্টারনেট কল চালু করতে WebRTC, signaling server এবং user account যোগ করতে হবে"
                            }) { Text("Start") }
                        }
                    }
                    Spacer(Modifier.height(16.dp))
                    Text(message, color = Color.Gray, fontSize = 12.sp)
                    Spacer(Modifier.height(8.dp))
                    Text(
                        "Internet calling is not connected yet. SIM call opens your phone app.",
                        fontSize = 11.sp,
                        color = Color.Gray
                    )
                }
                1 -> PlaceholderPage("Call History", "কলের ইতিহাস দেখানোর জন্য call-log permission ও UI যোগ করতে হবে.", padding)
                else -> PlaceholderPage("Contacts", "ফোনের পরিচিতি দেখাতে contacts permission ও contact picker যোগ করতে হবে.", padding)
            }
        }
    }
}

@Composable
private fun PlaceholderPage(title: String, description: String, padding: PaddingValues) {
    Column(
        Modifier.fillMaxSize().padding(padding).padding(24.dp),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Text(title, fontSize = 24.sp, fontWeight = FontWeight.Bold, color = Navy)
        Spacer(Modifier.height(10.dp))
        Text(description, color = Color.Gray)
    }
}

private fun requestDialerRole(context: Context) {
    if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
        val roleManager = context.getSystemService(RoleManager::class.java)
        if (roleManager.isRoleAvailable(RoleManager.ROLE_DIALER) &&
            !roleManager.isRoleHeld(RoleManager.ROLE_DIALER)) {
            val intent = roleManager.createRequestRoleIntent(RoleManager.ROLE_DIALER)
            if (context is ComponentActivity) {
                context.startActivity(intent)
            } else {
                intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
                context.startActivity(intent)
            }
        }
    }
}
