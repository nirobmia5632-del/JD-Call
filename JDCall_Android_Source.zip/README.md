# JD Call — Android starter project

JD Call is a Kotlin + Jetpack Compose starter for:
- SIM calls: opens the system dialer with a number (user confirms the call).
- Default phone-app setup: requests Android's dialer role. A production dialer must implement and thoroughly test the full InCallService/Telecom contract.
- Internet calling: includes a clear integration point and setup notes. Real app-to-app VoIP requires WebRTC plus a signaling service and push notifications; this starter does not pretend that a backend exists.

## Requirements
- Android Studio (recent stable)
- JDK 17
- Android SDK 35
- Internet connection for Gradle dependencies

## Open and run
1. Extract the ZIP.
2. In Android Studio choose **Open** and select this folder.
3. Allow Gradle sync to finish.
4. Run on a real Android phone or emulator.
5. Test SIM call by entering a phone number and tapping **SIM Call**.

## Important limitations
- `ACTION_DIAL` opens the phone app and leaves final dialing to the user. This is safer and avoids silently placing calls.
- Requesting the dialer role alone does not make this app a complete production phone app. To receive/control SIM calls inside JD Call, finish the Android Telecom `InCallService` implementation, provide the required incoming/ongoing call UI, and test across manufacturers and Android versions.
- VoIP is not live yet. It needs a WebRTC client, authenticated signaling server (for example WebSocket), STUN/TURN configuration, incoming-call push notifications, and user/account provisioning. Do not use this project for emergency calls.
- The app is a new design inspired by common calling-app patterns, not a copy of Brilliant's branding or private implementation.

## Project structure
- `app/src/main/java/com/jdcall/app/MainActivity.kt` — UI, number entry, dialer role request, SIM dial intent, VoIP placeholder.
- `app/src/main/AndroidManifest.xml` — permissions and Telecom service declaration.
- `app/src/main/java/com/jdcall/app/JdInCallService.kt` — minimal Telecom service scaffold; production call UI/control is still required.

## Next production steps
1. Implement full `InCallService` call lifecycle and notification handling.
2. Add contact permission flow and contact picker.
3. Integrate WebRTC and signaling backend.
4. Add account registration, authentication, abuse prevention, privacy policy, and secure push delivery.
5. Test incoming/outgoing calls with multiple SIMs and devices.
